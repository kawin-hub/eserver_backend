import{aR as i}from"./index.dc90d0c7.js";const t=()=>i();export{t as u};
