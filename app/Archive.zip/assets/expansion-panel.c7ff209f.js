import{V as T}from"./VBtn.5ca26f7c.js";import{a as c,b as r,c as p,V as g}from"./VExpansionPanel.50eb698f.js";import{k as y,o as i,c as P,m as o,p as a,w as e,E as n,x as h,q as E,F as V,a as b,b as m,D as I,C as v,L as k}from"./index.dc90d0c7.js";import{_ as B}from"./AppCardCode.82fe9d8b.js";import{a as f,V as q}from"./VRow.a1d8e599.js";import"./router.9f5abff7.js";import"./position.734f74ac.js";import"./index.35436ddd.js";import"./lazy.1f3570de.js";import"./vue.runtime.esm-bundler.70283b6a.js";import"./VCard.ef7570db.js";import"./VAvatar.6d3c69e8.js";import"./VImg.3d76415f.js";import"./VDivider.09f7ba48.js";const S={class:"mb-4"},D={class:"mt-3"},z=o("span",{class:"font-weight-bold"},"Selected: ",-1),A={__name:"DemoExpansionPanelModel",setup(u){const t=y([]),l=y(5),d=()=>{t.value=[...Array(l.value).keys()]},s=()=>{t.value=[]};return(w,_)=>(i(),P("div",null,[o("div",S,[a(T,{class:"me-4",onClick:d},{default:e(()=>[n(" all ")]),_:1}),a(T,{color:"error",onClick:s},{default:e(()=>[n(" none ")]),_:1}),o("div",D,[z,n(h(E(t)),1)])]),a(g,{modelValue:E(t),"onUpdate:modelValue":_[0]||(_[0]=x=>I(t)?t.value=x:null),multiple:""},{default:e(()=>[(i(!0),P(V,null,b(E(l),x=>(i(),m(c,{key:x},{default:e(()=>[a(r,null,{default:e(()=>[n("Header "+h(x),1)]),_:2},1024),a(p,null,{default:e(()=>[n(" I love I love jujubes halvah cheesecake cookie macaroon sugar plum. Sugar plum I love bear claw marzipan wafer. Wafer sesame snaps danish candy cheesecake carrot cake tootsie roll. ")]),_:1})]),_:2},1024))),128))]),_:1},8,["modelValue"])]))}},H={__name:"DemoExpansionPanelCustomIcon",setup(u){const t=y(0);return(l,d)=>(i(),m(g,{modelValue:E(t),"onUpdate:modelValue":d[0]||(d[0]=s=>I(t)?t.value=s:null)},{default:e(()=>[a(c,null,{default:e(()=>[a(r,{"disable-icon-rotate":""},{actions:e(()=>[a(v,{icon:"tabler-alert-circle",color:"error"})]),default:e(()=>[n(" Server Down ")]),_:1}),a(p,null,{default:e(()=>[n(" Gummies biscuit dessert macaroon liquorice carrot cake oat cake jelly beans cake. Candy wafer tiramisu sugar plum sweet. Ice cream topping gummies biscuit souffl\xE9 marzipan topping brownie marshmallow. Chocolate cake cookie pudding gummies cotton candy ice cream. Pie liquorice marzipan cake carrot cake macaroon jelly toffee. Lollipop donut gummi bears caramels icing marzipan. ")]),_:1})]),_:1}),a(c,null,{default:e(()=>[a(r,{"disable-icon-rotate":""},{actions:e(()=>[a(v,{icon:"tabler-check",color:"success"})]),default:e(()=>[n(" Sales report generated ")]),_:1}),a(p,null,{default:e(()=>[n(" Bear claw ice cream icing gummies gingerbread cotton candy tootsie roll cupcake macaroon. Halvah brownie souffl\xE9. Pie drag\xE9e macaroon. Tart tootsie roll chocolate bar biscuit jujubes lemon drops. Pudding cotton candy tart jelly-o bear claw lollipop. Jelly-o apple pie candy bonbon chupa chups cupcake cotton candy. Sweet roll cotton candy toffee caramels. Jelly-o chocolate cake toffee pastry halvah. Muffin tiramisu ice cream danish jelly-o brownie powde ")]),_:1})]),_:1}),a(c,null,{default:e(()=>[a(r,{"disable-icon-rotate":""},{actions:e(()=>[a(v,{icon:"tabler-alert-triangle",color:"warning"})]),default:e(()=>[n(" High Memory usage ")]),_:1}),a(p,null,{default:e(()=>[n(" Jelly beans wafer lemon drops macaroon muffin gummies muffin. Ice cream oat cake chocolate bar sesame snaps. Halvah macaroon caramels gummies. Marshmallow jelly beans danish. Cake chocolate cake tiramisu chocolate bar sugar plum biscuit jelly danish. Pudding gummi bears sesame snaps cake souffl\xE9 ice cream chocolate bar. Cotton candy ice cream danish chocolate cake topping ice cream. Brownie muffin gingerbread. ")]),_:1})]),_:1})]),_:1},8,["modelValue"]))}},$={};function M(u,t){return i(),m(g,{variant:"popout"},{default:e(()=>[(i(),P(V,null,b(4,l=>a(c,{key:l},{default:e(()=>[a(r,null,{default:e(()=>[n("Popout "+h(l),1)]),_:2},1024),a(p,null,{default:e(()=>[n(" Cupcake ipsum dolor sit amet. Candy canes cheesecake chocolate bar I love I love jujubes gummi bears ice cream. Cheesecake tiramisu toffee cheesecake sugar plum candy canes bonbon candy. ")]),_:1})]),_:2},1024)),64))]),_:1})}const J=k($,[["render",M]]),L={};function U(u,t){return i(),m(g,{variant:"inset"},{default:e(()=>[(i(),P(V,null,b(4,l=>a(c,{key:l},{default:e(()=>[a(r,null,{default:e(()=>[n("Inset "+h(l),1)]),_:2},1024),a(p,null,{default:e(()=>[n(" Chocolate bar sweet roll chocolate cake pastry I love gummi bears pudding chocolate cake. I love brownie powder apple pie sugar plum I love cake candy canes wafer. Tiramisu I love oat cake oat cake danish icing. Dessert sugar plum sugar plum cookie donut chocolate cake oat cake I love gummi bears. ")]),_:1})]),_:2},1024)),64))]),_:1})}const W=k(L,[["render",U]]),G={};function N(u,t){return i(),m(g,{variant:"accordion"},{default:e(()=>[(i(),P(V,null,b(4,l=>a(c,{key:l},{default:e(()=>[a(r,null,{default:e(()=>[n(" Accordion "+h(l),1)]),_:2},1024),a(p,null,{default:e(()=>[n(" Sweet roll ice cream chocolate bar. Ice cream croissant sugar plum I love cupcake gingerbread liquorice cake. Bonbon tart caramels marshmallow chocolate cake icing icing danish pie. ")]),_:1})]),_:2},1024)),64))]),_:1})}const F=k(G,[["render",N]]),R={};function K(u,t){return i(),m(g,{multiple:""},{default:e(()=>[(i(),P(V,null,b(4,l=>a(c,{key:l},{default:e(()=>[a(r,null,{default:e(()=>[n(" Item "+h(l),1)]),_:2},1024),a(p,null,{default:e(()=>[n(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")]),_:1})]),_:2},1024)),64))]),_:1})}const O=k(R,[["render",K]]),Q={ts:`<template>
  <VExpansionPanels variant="accordion">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>
        Accordion {{ item }}
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Sweet roll ice cream chocolate bar. Ice cream croissant sugar plum I love cupcake gingerbread liquorice cake. Bonbon tart caramels marshmallow chocolate cake icing icing danish pie.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`,js:`<template>
  <VExpansionPanels variant="accordion">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>
        Accordion {{ item }}
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Sweet roll ice cream chocolate bar. Ice cream croissant sugar plum I love cupcake gingerbread liquorice cake. Bonbon tart caramels marshmallow chocolate cake icing icing danish pie.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`},X={ts:`<template>
  <VExpansionPanels multiple>
    <VExpansionPanel
      v-for="i in 4"
      :key="i"
    >
      <VExpansionPanelTitle>
        Item {{ i }}
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`,js:`<template>
  <VExpansionPanels multiple>
    <VExpansionPanel
      v-for="i in 4"
      :key="i"
    >
      <VExpansionPanelTitle>
        Item {{ i }}
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`},Y={ts:`<script setup lang="ts">
const panel = ref(0)
<\/script>

<template>
  <VExpansionPanels v-model="panel">
    <VExpansionPanel>
      <VExpansionPanelTitle disable-icon-rotate>
        Server Down
        <template #actions>
          <VIcon
            icon="tabler-alert-circle"
            color="error"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Gummies biscuit dessert macaroon liquorice carrot cake oat cake jelly beans cake. Candy wafer tiramisu sugar plum sweet. Ice cream topping gummies biscuit souffl\xE9 marzipan topping brownie marshmallow. Chocolate cake cookie pudding gummies cotton candy ice cream. Pie liquorice marzipan cake carrot cake macaroon jelly toffee. Lollipop donut gummi bears caramels icing marzipan.
      </VExpansionPanelText>
    </VExpansionPanel>

    <VExpansionPanel>
      <VExpansionPanelTitle
        disable-icon-rotate
      >
        Sales report generated
        <template #actions>
          <VIcon
            icon="tabler-check"
            color="success"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Bear claw ice cream icing gummies gingerbread cotton candy tootsie roll cupcake macaroon. Halvah brownie souffl\xE9. Pie drag\xE9e macaroon. Tart tootsie roll chocolate bar biscuit jujubes lemon drops. Pudding cotton candy tart jelly-o bear claw lollipop. Jelly-o apple pie candy bonbon chupa chups cupcake cotton candy. Sweet roll cotton candy toffee caramels. Jelly-o chocolate cake toffee pastry halvah. Muffin tiramisu ice cream danish jelly-o brownie powde
      </VExpansionPanelText>
    </VExpansionPanel>

    <VExpansionPanel>
      <VExpansionPanelTitle disable-icon-rotate>
        High Memory usage
        <template #actions>
          <VIcon
            icon="tabler-alert-triangle"
            color="warning"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Jelly beans wafer lemon drops macaroon muffin gummies muffin. Ice cream oat cake chocolate bar sesame snaps. Halvah macaroon caramels gummies. Marshmallow jelly beans danish. Cake chocolate cake tiramisu chocolate bar sugar plum biscuit jelly danish. Pudding gummi bears sesame snaps cake souffl\xE9 ice cream chocolate bar. Cotton candy ice cream danish chocolate cake topping ice cream. Brownie muffin gingerbread.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`,js:`<script setup>
const panel = ref(0)
<\/script>

<template>
  <VExpansionPanels v-model="panel">
    <VExpansionPanel>
      <VExpansionPanelTitle disable-icon-rotate>
        Server Down
        <template #actions>
          <VIcon
            icon="tabler-alert-circle"
            color="error"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Gummies biscuit dessert macaroon liquorice carrot cake oat cake jelly beans cake. Candy wafer tiramisu sugar plum sweet. Ice cream topping gummies biscuit souffl\xE9 marzipan topping brownie marshmallow. Chocolate cake cookie pudding gummies cotton candy ice cream. Pie liquorice marzipan cake carrot cake macaroon jelly toffee. Lollipop donut gummi bears caramels icing marzipan.
      </VExpansionPanelText>
    </VExpansionPanel>

    <VExpansionPanel>
      <VExpansionPanelTitle
        disable-icon-rotate
      >
        Sales report generated
        <template #actions>
          <VIcon
            icon="tabler-check"
            color="success"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Bear claw ice cream icing gummies gingerbread cotton candy tootsie roll cupcake macaroon. Halvah brownie souffl\xE9. Pie drag\xE9e macaroon. Tart tootsie roll chocolate bar biscuit jujubes lemon drops. Pudding cotton candy tart jelly-o bear claw lollipop. Jelly-o apple pie candy bonbon chupa chups cupcake cotton candy. Sweet roll cotton candy toffee caramels. Jelly-o chocolate cake toffee pastry halvah. Muffin tiramisu ice cream danish jelly-o brownie powde
      </VExpansionPanelText>
    </VExpansionPanel>

    <VExpansionPanel>
      <VExpansionPanelTitle disable-icon-rotate>
        High Memory usage
        <template #actions>
          <VIcon
            icon="tabler-alert-triangle"
            color="warning"
          />
        </template>
      </VExpansionPanelTitle>
      <VExpansionPanelText>
        Jelly beans wafer lemon drops macaroon muffin gummies muffin. Ice cream oat cake chocolate bar sesame snaps. Halvah macaroon caramels gummies. Marshmallow jelly beans danish. Cake chocolate cake tiramisu chocolate bar sugar plum biscuit jelly danish. Pudding gummi bears sesame snaps cake souffl\xE9 ice cream chocolate bar. Cotton candy ice cream danish chocolate cake topping ice cream. Brownie muffin gingerbread.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`},Z={ts:`<template>
  <VExpansionPanels variant="inset">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>Inset {{ item }}</VExpansionPanelTitle>
      <VExpansionPanelText>
        Chocolate bar sweet roll chocolate cake pastry I love gummi bears pudding chocolate cake. I love brownie powder apple pie sugar plum I love cake candy canes wafer. Tiramisu I love oat cake oat cake danish icing. Dessert sugar plum sugar plum cookie donut chocolate cake oat cake I love gummi bears.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`,js:`<template>
  <VExpansionPanels variant="inset">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>Inset {{ item }}</VExpansionPanelTitle>
      <VExpansionPanelText>
        Chocolate bar sweet roll chocolate cake pastry I love gummi bears pudding chocolate cake. I love brownie powder apple pie sugar plum I love cake candy canes wafer. Tiramisu I love oat cake oat cake danish icing. Dessert sugar plum sugar plum cookie donut chocolate cake oat cake I love gummi bears.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`},ee={ts:`<script lang="ts" setup>
const openedPanels = ref<number[]>([])

const items = ref(5)

const all = () => {
  // [...Array(5).keys()] => [0, 1, 2, 3, 4]
  openedPanels.value = [...Array(items.value).keys()]
}

const none = () => {
  openedPanels.value = []
}
<\/script>

<template>
  <div>
    <div class="mb-4">
      <VBtn
        class="me-4"
        @click="all"
      >
        all
      </VBtn>

      <VBtn
        color="error"
        @click="none"
      >
        none
      </VBtn>

      <div class="mt-3">
        <span class="font-weight-bold">Selected: </span>{{ openedPanels }}
      </div>
    </div>

    <VExpansionPanels
      v-model="openedPanels"
      multiple
    >
      <VExpansionPanel
        v-for="item in items"
        :key="item"
      >
        <VExpansionPanelTitle>Header {{ item }}</VExpansionPanelTitle>
        <VExpansionPanelText>
          I love I love jujubes halvah cheesecake cookie macaroon sugar plum. Sugar plum I love bear claw marzipan wafer. Wafer sesame snaps danish candy cheesecake carrot cake tootsie roll.
        </VExpansionPanelText>
      </VExpansionPanel>
    </VExpansionPanels>
  </div>
</template>
`,js:`<script setup>
const openedPanels = ref([])
const items = ref(5)

const all = () => {

  // [...Array(5).keys()] => [0, 1, 2, 3, 4]
  openedPanels.value = [...Array(items.value).keys()]
}

const none = () => {
  openedPanels.value = []
}
<\/script>

<template>
  <div>
    <div class="mb-4">
      <VBtn
        class="me-4"
        @click="all"
      >
        all
      </VBtn>

      <VBtn
        color="error"
        @click="none"
      >
        none
      </VBtn>

      <div class="mt-3">
        <span class="font-weight-bold">Selected: </span>{{ openedPanels }}
      </div>
    </div>

    <VExpansionPanels
      v-model="openedPanels"
      multiple
    >
      <VExpansionPanel
        v-for="item in items"
        :key="item"
      >
        <VExpansionPanelTitle>Header {{ item }}</VExpansionPanelTitle>
        <VExpansionPanelText>
          I love I love jujubes halvah cheesecake cookie macaroon sugar plum. Sugar plum I love bear claw marzipan wafer. Wafer sesame snaps danish candy cheesecake carrot cake tootsie roll.
        </VExpansionPanelText>
      </VExpansionPanel>
    </VExpansionPanels>
  </div>
</template>
`},ae={ts:`<template>
  <VExpansionPanels variant="popout">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>Popout {{ item }}</VExpansionPanelTitle>
      <VExpansionPanelText>
        Cupcake ipsum dolor sit amet. Candy canes cheesecake chocolate bar I love I love jujubes gummi bears ice cream. Cheesecake tiramisu toffee cheesecake sugar plum candy canes bonbon candy.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`,js:`<template>
  <VExpansionPanels variant="popout">
    <VExpansionPanel
      v-for="item in 4"
      :key="item"
    >
      <VExpansionPanelTitle>Popout {{ item }}</VExpansionPanelTitle>
      <VExpansionPanelText>
        Cupcake ipsum dolor sit amet. Candy canes cheesecake chocolate bar I love I love jujubes gummi bears ice cream. Cheesecake tiramisu toffee cheesecake sugar plum candy canes bonbon candy.
      </VExpansionPanelText>
    </VExpansionPanel>
  </VExpansionPanels>
</template>
`},ne=o("p",null,[n("Expansion panels in their simplest form display a list of expandable items. However, with the "),o("code",null,"multiple"),n(" prop, the expansion-panel can remain open until explicitly closed.")],-1),oe=o("p",null,[n("Use "),o("code",null,"accordion"),n(" variant option to create "),o("strong",null,"Accordion"),n(" Panels. Accordion expansion-panel hasn't got margins around active panel.")],-1),le=o("p",null,[n("Use "),o("code",null,"inset"),n(" variant option to create Inset Panels. The Inset expansion-panel becomes smaller when activated.")],-1),te=o("p",null,[n(" Use "),o("code",null,"popout"),n(" variant option to create expansion-panel with popout design. With it, expansion-panel is enlarged when activated. ")],-1),ie=o("p",null,[n("Expand action icon can be customized with "),o("code",null,"expand-icon"),n(" prop or the "),o("code",null,"actions"),n(" slot.")],-1),se=o("p",null,[n("Expansion panels can be controlled externally by modifying the "),o("code",null,"v-model"),n(". If "),o("code",null,"multiple"),n(" prop is used then it is an array containing the indices of the open items.")],-1),Ee={__name:"expansion-panel",setup(u){return(t,l)=>{const d=O,s=B,w=F,_=W,x=J,j=H,C=A;return i(),m(q,{class:"match-height"},{default:e(()=>[a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Basic",variant:"text",border:"",code:X},{default:e(()=>[ne,a(d)]),_:1},8,["code"])]),_:1}),a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Accordion",variant:"text",border:"",code:Q},{default:e(()=>[oe,a(w)]),_:1},8,["code"])]),_:1}),a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Inset",variant:"text",border:"",code:Z},{default:e(()=>[le,a(_)]),_:1},8,["code"])]),_:1}),a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Popout",variant:"text",border:"",code:ae},{default:e(()=>[te,a(x)]),_:1},8,["code"])]),_:1}),a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Custom Icon",variant:"text",border:"",code:Y},{default:e(()=>[ie,a(j)]),_:1},8,["code"])]),_:1}),a(f,{cols:"12",md:"6"},{default:e(()=>[a(s,{title:"Model",variant:"text",border:"",code:ee},{default:e(()=>[se,a(C)]),_:1},8,["code"])]),_:1})]),_:1})}}};export{Ee as default};
