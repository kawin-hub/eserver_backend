import{L as o}from"./index.cb840b2e.js";import{bk as r}from"./index.dc90d0c7.js";const e=new o({url:r.api.url+"products/models"});export{e as u};
