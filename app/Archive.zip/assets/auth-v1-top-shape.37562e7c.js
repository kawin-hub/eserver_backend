const a="/assets/auth-v1-bottom-shape.a51828f3.svg",s="/assets/auth-v1-top-shape.fe53cb96.svg";export{s as a,a as b};
