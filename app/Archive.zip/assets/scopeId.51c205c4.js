import{ag as o}from"./index.dc90d0c7.js";function c(){const e=o("useScopeId").vnode.scopeId;return{scopeId:e?{[e]:""}:void 0}}export{c as u};
