const s="/assets/404.fee4b60b.png";export{s as m};
