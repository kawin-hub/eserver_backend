import{L as e,o as c,c as n}from"./index.dc90d0c7.js";const o={};function r(t,a){return c(),n("p",null,"Nav level 3.1")}const s=e(o,[["render",r]]);export{s as default};
