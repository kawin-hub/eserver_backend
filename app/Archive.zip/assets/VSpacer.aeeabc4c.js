import{c as e}from"./VAvatar.6d3c69e8.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
