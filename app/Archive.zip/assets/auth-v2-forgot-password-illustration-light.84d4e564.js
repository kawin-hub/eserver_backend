const t="/assets/auth-v2-forgot-password-illustration-dark.ade65f2e.png",s="/assets/auth-v2-forgot-password-illustration-light.1ef614ab.png";export{t as a,s as b};
