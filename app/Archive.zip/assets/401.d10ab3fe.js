const s="/assets/401.605d79f7.png";export{s as p};
